package com.cg.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "Micro-Service1")
public interface MS1ServiceClient {
   @GetMapping("/show") //
	public String getMsg(); //http://localhost:9091/show
	
}
