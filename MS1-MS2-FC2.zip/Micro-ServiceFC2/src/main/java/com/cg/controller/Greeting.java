package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;
import com.cg.client.MS1ServiceClient;

@RestController
public class Greeting {
	
	//creating object for feignlclient interface
	
	
	
	@Autowired
	private MS1ServiceClient fclient;
	
	@GetMapping("/greet") //http://localhost:8091/greet
	public String getMsg() {
		//
		String ms1 = fclient.getMsg();//8090
		
		return "FROM MICROSERVICE_FC2:"+ms1;
		
	}
	
	//http://localhost:9090/fetchProduct  --Product
	
	@GetMapping("/fetch")
	public Product getProductFromMS2() {
		return fclient.getAllProduct();
	}
	
	

}
