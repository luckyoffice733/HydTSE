package com.cg.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.cg.bean.Product;

@FeignClient(name = "Micro-Service1")
public interface MS1ServiceClient {
   @GetMapping("/show") //
	public String getMsg(); //http://localhost:8090/show
   
  //note: return type should match followed by no of methodparameter
   @GetMapping("/fetchProduct") //http://localhost:8090/fetchProduct
   public Product getAllProduct();
   
}
