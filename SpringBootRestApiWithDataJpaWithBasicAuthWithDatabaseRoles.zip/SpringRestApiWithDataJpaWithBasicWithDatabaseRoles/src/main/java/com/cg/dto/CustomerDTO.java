package com.cg.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDTO {
	
	private Long customerId;

	@NotNull(message = "{name.notnull}")
	@NotEmpty(message ="Name Should not be empty")
	@Pattern(regexp = "[a-zA-Z]+",message = "Name should contain only characters")
	private String name;
	
	@Email(message = "Please Enter Valid Email Address")  //@
	private String email;
	
	@PastOrPresent(message = "{dob}")
	private LocalDate dateOfBirth;
	
	
	
	

}
