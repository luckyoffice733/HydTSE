package com.cg.exception;

public class CustomerNotFoundException extends Exception{

	public CustomerNotFoundException(String msg) {
		super(msg);
	}
	
}
