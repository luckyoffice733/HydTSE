package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.entity.Address;
import com.cg.entity.Employee;
import com.cg.service.EmployeeServiceImpl;

@SpringBootApplication
public class DemoOnSpringDataJpaOneToOneApplication implements CommandLineRunner {

	@Autowired
	private EmployeeServiceImpl emImpl;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringDataJpaOneToOneApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		//insert 
		Employee em = new Employee();
		em.setEmpName("smith");
		em.setEmpSal(5000);
		
		Address ad = new Address();
		ad.setStreetName("kokapeta");
		ad.setCity("Cyberbad");
		 em.setAddrs(ad);
		 
		long id = emImpl.addEmployee(em);
		System.out.println("Record inserted ..."+id);
	}

}
