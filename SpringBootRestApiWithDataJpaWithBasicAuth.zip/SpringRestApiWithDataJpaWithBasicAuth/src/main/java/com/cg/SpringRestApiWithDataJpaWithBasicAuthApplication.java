package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestApiWithDataJpaWithBasicAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestApiWithDataJpaWithBasicAuthApplication.class, args);
	}

}
