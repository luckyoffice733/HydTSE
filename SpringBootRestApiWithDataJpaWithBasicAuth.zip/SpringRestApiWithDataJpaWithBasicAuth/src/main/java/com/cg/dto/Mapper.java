package com.cg.dto;

import com.cg.entity.Customer;

public class Mapper {

	public static Customer convertCustomerDTOToCustomer(CustomerDTO cust) {
		Customer cobj = new Customer();
		cobj.setName(cust.getName());
       cobj.setEmail(cust.getEmail());
       cobj.setDateOfBirth(cust.getDateOfBirth());
		return cobj;
	}
	
	
	public static CustomerDTO convertCustomerToCustomerDTO(Customer cust) {
		CustomerDTO cobj = new CustomerDTO();
		cobj.setCustomerId(cust.getCustomerId());
		cobj.setName(cust.getName());
       cobj.setEmail(cust.getEmail());
       cobj.setDateOfBirth(cust.getDateOfBirth());
		return cobj;
	}
	
}
