package com.cg.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalException {
	
	@ExceptionHandler(ProductNotFound.class)
	public ResponseEntity<Map<String,Integer>> handlerException(ProductNotFound ex){
		 String msg = ex.getMessage();
		 int errrorCode = HttpStatus.NOT_FOUND.value();
		 
		 Map<String,Integer> hm = new HashMap<>();
		 hm.put(msg,errrorCode);
		 
		return new ResponseEntity<Map<String,Integer>>(hm,HttpStatus.NOT_FOUND);
		
		
	}
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Map<String,Integer>> handlerAllException(Exception ex){
		 String msg = "Request Not Processing Due to some technical issues";
		 int errrorCode = HttpStatus.INTERNAL_SERVER_ERROR.value();
		 
		 Map<String,Integer> hm = new HashMap<>();
		 hm.put(msg,errrorCode);
		 
		return new ResponseEntity<Map<String,Integer>>(hm,HttpStatus.INTERNAL_SERVER_ERROR);
		
		
	}

}
