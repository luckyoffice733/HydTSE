package com.cg.service;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.netflix.eureka.EurekaDiscoveryClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.dto.Product;
import com.cg.dto.ResponseDTO;
import com.cg.entity.Order;
import com.cg.exception.OrderNotFoundException;
import com.cg.repo.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService{
	@Autowired
	private OrderRepository oRepository;

	@Autowired
	private RestTemplate restTemplate;
	
	
	
	@Override
	public Long addOrder(Order order) {
		// TODO Auto-generated method stub
		String pid = String.valueOf(order.getProductId());
		String qty= String.valueOf(order.getQuantity());
		
	   
	 String url="http://localhost:9091/api/products/{id}/{qty}";
		
		/*
		 * Map<String,String> hm = new HashMap<>(); hm.put("id", pid);
		 * hm.put("qty",qty);
		 */
		 
	   restTemplate.put(url,Product.class,pid,qty);
	
    
		  //System.out.println(p);
		 
		//restTemplate.exchange(url,HttpMethod.PUT,P);
		
		
		
		return oRepository.save(order).getOrderId();
	}

	@Override
	public List<Order> getAllOrders() throws OrderNotFoundException {
		// TODO Auto-generated method stub
		List<Order> allOrders = oRepository.findAll();
		if(allOrders.isEmpty()) {
			throw new OrderNotFoundException("Order Records NOt Found");
		}
		return allOrders;
	}

	@Override
	public Order getOrderById(Long id) throws OrderNotFoundException {
		// TODO Auto-generated method stub
		Optional<Order>  option = oRepository.findById(id);
		if(option.isEmpty()) {
			throw new OrderNotFoundException("No Recor found based on order id ");
		}
		
		return option.get();
	}

	@Override
	public ResponseDTO getOrderAndProductById(long id) throws OrderNotFoundException {
		ResponseDTO responseDTO = new ResponseDTO();
		Optional<Order>  option = oRepository.findById(id);
		if(option.isEmpty()) {
			throw new OrderNotFoundException("No Recor found based on order id ");
		}else {
			Order order = option.get();
			long pid=order.getProductId();
			String url="http://localhost:9091/api/products/{id}"; //consuming
			Product product= restTemplate.getForObject(url,Product.class,pid);
			
			
			responseDTO.setOrder(order);
			responseDTO.setProduct(product);
		}
		
		return responseDTO;
	}

	

}
