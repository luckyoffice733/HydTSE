package com.cg.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.entity.Order;
import com.cg.exception.OrderNotFoundException;
import com.cg.repo.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService{
	@Autowired
	private OrderRepository oRepository;

	@Autowired
	private RestTemplate restTemplate;
	
	@Override
	public Long addOrder(Order order) {
		// TODO Auto-generated method stub
		long pid = order.getProductId();
		long qty= order.getQuantity();
		
		String url="http://localhost:9090/api/products/{pid}/{qty}";
		
		Map<String,Long> hm = new HashMap<>();
		hm.put("id",pid );
		hm.put("qty",qty);
		
	   
	
    
		  //System.out.println(p);
		 
		//restTemplate.exchange(url,HttpMethod.PUT,P);
		
		
		
		return oRepository.save(order).getOrderId();
	}

	@Override
	public List<Order> getAllOrders() throws OrderNotFoundException {
		// TODO Auto-generated method stub
		List<Order> allOrders = oRepository.findAll();
		if(allOrders.isEmpty()) {
			throw new OrderNotFoundException("Order Records NOt Found");
		}
		return allOrders;
	}

	@Override
	public Order getOrderById(Long id) throws OrderNotFoundException {
		// TODO Auto-generated method stub
		Optional<Order>  option = oRepository.findById(id);
		if(option.isEmpty()) {
			throw new OrderNotFoundException("No Recor found based on order id ");
		}
		
		return option.get();
	}

}
