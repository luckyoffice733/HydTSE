package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Greeting {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/greet")
	public String getMsg() {
		
		//consuming the url of Ms1
		String url ="http://localhost:9090/show";
		
		String dataFromMs1 =restTemplate.getForObject(url,String.class);
		
		
		return "FROM MICRO-Service2 : Greeting from the MicroService2: "+dataFromMs1;
	}

}
