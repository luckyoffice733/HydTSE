package com.cg.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Welcome {

	@GetMapping("/show") //http://localhost:9090/show
	public String sayHello() {
		return "From Micro-Service1 : Welcome to microservuces";
	}
	
	
}
