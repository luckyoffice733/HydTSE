package com.cg;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.entity.Customer;
import com.cg.service.CustomerService;

@SpringBootApplication
public class DemoOnSpringDataJpaWithCustomeQueriesApplication implements CommandLineRunner {

	@Autowired
	private CustomerService cuService;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringDataJpaWithCustomeQueriesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Fetching the record by email field");
	  Customer cobj=	cuService.getCustomerByEmail("smith@gmail.com");
	  System.out.println(cobj);
	  
	  System.out.println("Fetcing the records by using name field with like operator");
	  
	   List<Customer> lst=  cuService.getCustomerByNameUsingLike("m%");
	   System.out.println(lst);
	   
	   System.out.println("Fetcing the records by using dateOfBirh field between operator");
	   
	   LocalDate sd1= LocalDate.of(2012,10,10);
	   LocalDate ed1= LocalDate.of(2012,10,12);
	   
	   List<Customer> lst1=  cuService.getCustomerByDate(sd1,ed1);
	   System.out.println(lst1);
	   
	   
    System.out.println("Fetcing the records by using dateOfBirh GreaterThan Keyword");
	   
	   LocalDate ld1= LocalDate.of(2012,10,11);
	   List<Customer> lst2=  cuService.getCustomerGreaterThanDate(ld1);
	   System.out.println(lst2);
	   
	   
	   System.out.println("Updateing with custom query");
	   int upRecord= cuService.updateCustomer("raju@gmail.com",4L);
	   
	   System.out.println("Record Updated ...."+upRecord);
	   
	}

}
