package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.entity.Customer;

public interface CustomerService {
	
	public Long addCustomer(Customer cust);
	public List<Customer> getAllCustomers();
	
	public Customer getCustomerByEmail(String email);
	
	public List<Customer> getCustomerByNameUsingLike(String name);
	
	public List<Customer> getCustomerByDate(LocalDate startdate,LocalDate enddate);
	
	public List<Customer> getCustomerGreaterThanDate(LocalDate dt);
	
	
	

}
