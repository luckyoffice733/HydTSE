package com.cg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.repo.CustomerRepository;

@Service
public class CustomerServiceImpl  implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Long addCustomer(Customer cust) {
	  Customer customer=customerRepository.save(cust);
	  return customer.getCustomerId();
	}

	@Override
	public List<Customer> getAllCustomers() {
		List<Customer>  records=  customerRepository.findAll();
		return records;
		
	}

	@Override
	public Customer getCustomerByEmail(String email) {
	
		return customerRepository.findByEmail(email);
		
		
	}

	@Override
	public List<Customer> getCustomerByNameUsingLike(String name) {
	 return customerRepository.findByNameLike(name);
	}

	@Override
	public List<Customer> getCustomerByDate(LocalDate startdate, LocalDate enddate) {
		//return customerRepository.findByDateOfBirthBetween(startdate, enddate);
		return customerRepository.getAllCustomerDateRange(startdate, enddate);
	}

	@Override
	public List<Customer> getCustomerGreaterThanDate(LocalDate dt) {
		//return customerRepository.findByDateOfBirthGreaterThan(dt);
		//return  customerRepository.getAllCustomerByDatePositional(dt);
		return customerRepository.getAllCustomerByDateNamed(dt);
	}

	@Override
	public int updateCustomer(String email, Long id) {
		// TODO Auto-generated method stub
		return customerRepository.updateCustomerEmail(email, id);
	}

	
}
