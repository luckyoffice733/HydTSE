package com.cg.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long> {

	
	//query with methodName using field email from entity class
	 public Customer  findByEmail(String email);
	 
	 public List<Customer> findByNameLike(String name);
	 
	 public List<Customer> findByDateOfBirthBetween(LocalDate startdate,LocalDate enddate );
	 
	 public List<Customer> findByDateOfBirthGreaterThan(LocalDate dt);
	 
	 
	 //Spring Data Query Approach using @query annotation  
	 @Query("select c from Customer c where c.dateOfBirth >:sd") //Named Parameter
	 public List<Customer> getAllCustomerByDateNamed(@Param("sd")   LocalDate sd);
	 
	 
	 //Spring Data Query Approach using @query annotation
	 @Query("select c from Customer c where c.dateOfBirth >?1") //positional parameter
	 public List<Customer> getAllCustomerByDatePositional(LocalDate sd);
}

