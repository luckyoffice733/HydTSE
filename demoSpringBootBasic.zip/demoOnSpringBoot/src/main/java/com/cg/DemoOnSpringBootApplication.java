package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.training.bean.Employee;

@SpringBootApplication
@ComponentScan(basePackages = {"com.training.bean"})
public class DemoOnSpringBootApplication  implements CommandLineRunner{
	
	@Autowired
	private Employee employee;

	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Employee Detials: ");
		System.out.println(employee.getEmpId()+" "+employee.getEmpName()+" "+employee.getEmpSal());
		
	}

	
	
}
