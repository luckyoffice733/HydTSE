package com.cg;

import java.time.LocalDate;
import java.util.List;

import javax.swing.plaf.synth.SynthStyleFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.entity.Customer;
import com.cg.service.CustomerService;




@SpringBootApplication
public class DemoOnSpringDataJpaWithCustomerBeanCrudApplication implements CommandLineRunner{

	@Autowired
    private CustomerService customerService;	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringDataJpaWithCustomerBeanCrudApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		//insert
		/*
		 * Customer c1 = new Customer(); c1.setName("martin");
		 * c1.setEmail("martin@gmail.com");
		 * 
		 * LocalDate ld = LocalDate.of(2012,10,12); c1.setDateOfBirth(ld);
		 * 
		 * long cid= customerService.addCustomer(c1);
		 * System.out.println("Customer Record Inserted ... "+cid);
		 */
		//retreive all records
		
		/*
		 * List<Customer> records= customerService.getAllCustomers();
		 * records.stream().forEach(System.out::println);
		 */
		
		//search record based on id
		/*
		 * Customer cust= customerService.getCustomerById(5L);
		 * System.out.println("Customer Record Found based on Id :");
		 * System.out.println(cust);
		 */
		
		//delete by id
		String msg=customerService.deleteCustomerById(5L);
		System.out.println(msg);
		
	}

}
