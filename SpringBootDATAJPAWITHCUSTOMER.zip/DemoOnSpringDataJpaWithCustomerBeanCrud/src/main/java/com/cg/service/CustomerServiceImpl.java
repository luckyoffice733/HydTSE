package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.repo.CustomerRepository;

@Service
public class CustomerServiceImpl  implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Long addCustomer(Customer cust) {
	  Customer customer=customerRepository.save(cust);
	  return customer.getCustomerId();
	}

	@Override
	public List<Customer> getAllCustomers() {
		List<Customer>  records=  customerRepository.findAll();
		return records;
		
	}

	@Override
	public Customer getCustomerById(Long id) {
	Optional<Customer> optal= customerRepository.findById(id);
		return optal.get();
		
	}

	@Override
	public String deleteCustomerById(Long id) {
		Optional<Customer> optal= customerRepository.findById(id);
		if(optal.isPresent()) {
			customerRepository.deleteById(optal.get().getCustomerId());
			return "Record is deleted successfully";
		}else {
			return "Record is not found";
		}
	}

}
