package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;

public interface CustomerService {
	
	public Long addCustomer(Customer cust);
	public List<Customer> getAllCustomers();
	public Customer getCustomerById(Long id);
	public String deleteCustomerById(Long id);
	

}
