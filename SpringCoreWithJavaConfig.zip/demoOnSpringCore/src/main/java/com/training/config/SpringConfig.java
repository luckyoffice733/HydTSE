package com.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.training.Employee;

@Configuration
public class SpringConfig {
	
	@Bean
	public Employee getEmployeeObject() {
		Employee employee = new Employee();
		employee.setEmpId(10121);
		employee.setEmpName("Smith");
		employee.setEmpSal(4000);
	    return employee;
	}
	
	

}
