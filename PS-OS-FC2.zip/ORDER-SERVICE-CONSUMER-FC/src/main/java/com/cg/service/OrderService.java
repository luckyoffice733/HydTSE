package com.cg.service;

import java.util.List;

import com.cg.dto.ResponseDTO;
import com.cg.entity.Order;
import com.cg.exception.OrderNotFoundException;

public interface OrderService {
    
	public Long addOrder(Order order);
	public List<Order> getAllOrders() throws OrderNotFoundException;
	public Order getOrderById(Long id) throws OrderNotFoundException;
	public ResponseDTO getOrderAndProductById(long id) throws OrderNotFoundException;
	}
