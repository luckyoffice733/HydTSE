package com.cg.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.entity.Product;


@FeignClient(name = "PRODUCT-SERVICE-PROVIDER")
public interface ProductServiceFeignCLient {

	@GetMapping("/api/products/{id}")//http://localhost:8010/api/products/3
	public Product getProductById(@PathVariable long id);
}
