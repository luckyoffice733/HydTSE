package com.cg.dto;

import com.cg.entity.Order;
import com.cg.entity.Product;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseDTO {

	private Order  order;
	private Product product;
}
