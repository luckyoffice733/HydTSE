package com.cg.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;

@RestController
public class Welcome {

	@GetMapping("/show") //http://localhost:9090/show
	public String sayHello() {
		return "From Micro-Service1 : Welcome to microservuces";
	}
	
	@GetMapping("/fetchProduct")//http://localhost:9090/fetchProduct
	public Product getProduct() {
		return new Product(2121L,"mouse", 800);
	}

	@PostMapping("/add") //http://localhost:9090/add
	public String addProduct(@RequestBody Product prod) {
		return "Product Details are : \n Pid: "+prod.getPid()+" "+prod.getProductName();
	}
	
}
