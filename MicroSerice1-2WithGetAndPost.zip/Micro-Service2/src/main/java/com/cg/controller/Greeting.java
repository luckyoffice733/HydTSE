package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.dto.Product;

@RestController
public class Greeting {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/greet")
	public String getMsg() {
		
		//consuming the url of Ms1
		String url ="http://localhost:9090/show";
		
		String dataFromMs1 =restTemplate.getForObject(url,String.class);
		
		
		return "FROM MICRO-Service2 : Greeting from the MicroService2: "+dataFromMs1;
	}
	
	//http://localhost:9090/fetchProduct  --Product
	
	@GetMapping("/ms2product")
	public Product getProductDetailsFromMS1() {
		String url="http://localhost:9090/fetchProduct";
		
	Product product=	restTemplate.getForObject(url,Product.class);
		return product;
	}
	
	@GetMapping("/ms2")
	public String ms2AddProduct() {
		String url="http://localhost:9090/add";
		Product p =new Product(3122L,"laptop",40000);
		String  msg =restTemplate.postForObject(url,p,String.class);
		return msg;
	}
	
	
	

}
