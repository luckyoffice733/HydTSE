package com.training;

public interface MyApp {

	public void methodOne();
	
}
