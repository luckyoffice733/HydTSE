package com.training;

class Test {
	int a =10;
	public void methodOne() {
		System.out.println("we are in methodOne");
	}
}
public class A extends Test{
	int a=20;
	
	public void methodTwo() {
		System.out.println("we are in methodTwo");
	}
	
	public void methodOne() {
		System.out.println("we are in methodOne of child class");
	}
	public static void main(String[] args) {
		A aob = new A();
		//Test tobj = new A(); //polymorphism
		System.out.println(aob.a);
		aob.methodOne();
		aob.methodTwo();
		
		Test tobj = new A(); //polymorphism
		
		//System.out.println(this.a);
		
		  System.out.println("variable value is : "+tobj.a);
          tobj.methodOne();
		   //tobj.methodTwo();
		
	}

	
}
