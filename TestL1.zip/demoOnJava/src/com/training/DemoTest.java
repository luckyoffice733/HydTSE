package com.training;

public class DemoTest {

	static int a=1;
	
	static { //static block
		System.out.println(a);
	}
	
	{//instance block
		System.out.println(23);
	}
	
	public DemoTest() {
		System.out.println(3);
	}
	
	public static void main(String[] args) {
		DemoTest al = new DemoTest();
		DemoTest a2 = new DemoTest();
	}
	
}
