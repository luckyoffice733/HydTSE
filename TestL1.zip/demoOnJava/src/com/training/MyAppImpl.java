package com.training;

public class MyAppImpl implements MyApp{

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		System.out.println("we are in methodOne");
	}
	
	public void methodTwo() {
		System.out.println("we are in methodTwo");
	}
	
	public static void main(String[] args) {
		MyAppImpl myobj = new MyAppImpl();
		myobj.methodOne();
		myobj.methodTwo();
		
	//Interace reference variable  holding its implementation
		//object is called polymorphism
      MyApp myobj1 = new MyAppImpl();	
		myobj1.methodOne();
	//	myobj1.methodTwo(); here you will the error
		
		
	}

}
