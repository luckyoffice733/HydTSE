package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;
import com.cg.exception.CustomerNotFoundException;

public interface CustomerService {
	
     public Long addCustomer(Customer cust);
     public List<Customer> getAllCustomers();
     public Customer getCustomerById(Long id)throws CustomerNotFoundException;
}
