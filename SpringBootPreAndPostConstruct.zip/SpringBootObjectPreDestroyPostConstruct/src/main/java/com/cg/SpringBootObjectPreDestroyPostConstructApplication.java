package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.bean.Product;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

@SpringBootApplication
public class SpringBootObjectPreDestroyPostConstructApplication  implements CommandLineRunner{

	@Autowired
	private Product product;
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootObjectPreDestroyPostConstructApplication.class, args);
		
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(product.hashCode());
	}
	
	@PostConstruct
	public void methodOne() {
		System.out.println("after  object created then we need to some operations");
	}
	
	@PreDestroy
	public void methodTwo() {
		System.out.println("this method will called before  destroying the bean objects");
	}
	
	

}
