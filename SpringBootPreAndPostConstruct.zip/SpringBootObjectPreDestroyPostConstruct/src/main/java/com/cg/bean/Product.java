package com.cg.bean;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Product {

	@Value("121")
	private int pid;
	
	@Value("mobile")
	private String pname;
	
	@Value("10000")
	private double price;
	
	@Value("${qty}")//reading the qty key from the properties files.
	private List<Integer> qty;
	
	
	public Product() {
		System.out.println("we are in default constructor of product class");
	}
	
	
    public List<Integer> getQty() {
		return qty;
	}
	public void setQty(List<Integer> qty) {
		this.qty = qty;
	}
	
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	
	
	
	
	
}
